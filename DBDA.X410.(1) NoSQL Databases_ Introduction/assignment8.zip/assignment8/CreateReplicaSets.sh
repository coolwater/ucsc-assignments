#!/bin/bash -x
sudo service mongodb stop
sleep 2
sudo rm -fr /data/shard1
sudo rm -fr /data/shard2
sudo rm -fr /data/configsrv

sleep 2
sudo mkdir -p /data
sudo chmod 777 /data

sleep 2
mkdir -p /data/shard1/db01
mkdir -p /data/shard1/db02
mkdir -p /data/shard1/db03
sleep 2
mkdir -p /data/shard2/db01
mkdir -p /data/shard2/db02
mkdir -p /data/shard2/db03

mkdir -p /data/configsrv
sleep 2
gnome-terminal -e "mongod --shardsvr --replSet rzset01 --dbpath /data/shard1/db01 --port 27019"
sleep 5
gnome-terminal -e "mongod --shardsvr --replSet rzset01 --dbpath /data/shard1/db02 --port 27020"
sleep 5
gnome-terminal -e "mongod --shardsvr --replSet rzset02 --dbpath /data/shard2/db01 --port 27021"
sleep 5
gnome-terminal -e "mongod --shardsvr --replSet rzset02 --dbpath /data/shard2/db02 --port 27022"
sleep 5

