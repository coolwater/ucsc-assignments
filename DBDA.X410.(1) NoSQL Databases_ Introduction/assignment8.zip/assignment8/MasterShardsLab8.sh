#!/bin/bash -x
./CreateReplicaSets.sh
./CreateConfigurationServer.sh
./SetupCluster.sh
./AddDataToCluster.sh

