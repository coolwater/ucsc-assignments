// mongo localhost:27021 s05-config-rzset02.js
config = {
	_id : "rzset02",
	members : [
		{_id : 0, host : "localhost:27021"},
		{_id : 1, host : "localhost:27022"}
	]
};

rs.initiate(config);
print("initiated rzset02 configuration");
