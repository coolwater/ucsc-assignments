// mongo localhost:27019 s08a-check-shard01-status.js
var cnt = 0;
while (cnt < 49900) {
	cnt = db.users.find().count();
	sleep(2000);
	print("Inserted "+cnt+" user records into shard01");
}
var users3 = db.users.find().limit(3).skip(1000);
print("db.users.find().limit(3).skip(1000)=");
while (users3.hasNext()) {
	printjson(users3.next());
}

print("db.isMaster()="+db.isMaster());
print("db.isMaster.ismaster="+db.isMaster().ismaster);

