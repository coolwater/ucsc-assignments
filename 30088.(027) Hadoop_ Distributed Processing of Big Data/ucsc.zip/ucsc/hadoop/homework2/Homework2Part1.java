package ucsc.hadoop.homework2;

import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;

public class Homework2Part1 extends Configured implements Tool {
    
    public int run(String[] args) throws Exception {
        
        Configuration conf = getConf();
        
        if (args.length != 2) {
            System.err.println("Usage: Homework2Part1 <input-file> <outtput-file>");
            System.exit(2);
        }
        
        Job job = Job.getInstance(conf);
        
        job.setJobName("Homework2Part1");
        
        job.setJarByClass(Homework2Part1.class);
        
        FileInputFormat.setInputPaths(job, new Path(args[0]));
        FileOutputFormat.setOutputPath(job, new Path(args[1]));        
        
        job.setMapperClass(Homework2Part1Mapper.class);
        job.setReducerClass(Homework2Part1Reducer.class);
        
        job.setInputFormatClass(TextInputFormat.class);
        job.setOutputFormatClass(TextOutputFormat.class);
        
        job.setMapOutputKeyClass(Text.class);
        job.setMapOutputValueClass(Text.class);

        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(Text.class);

        boolean result = job.waitForCompletion(true);
        return (result) ? 0 : 1;
    }
    
    public static class Homework2Part1Mapper extends Mapper<LongWritable, Text, Text, Text> {
        
        @Override
        public void map(LongWritable key, Text value, Context context) 
                throws IOException, InterruptedException {
            
            // values are separated by a tab
            String[] tokens = value.toString().split("\\t");
            
            if (tokens.length == 3) {
                // actor name - token[0], movie name - tokens[1], year of production - token[2]
                context.write(new Text(tokens[1]+" ("+tokens[2]+")"), new Text(tokens[0]));
            } else {
                System.err.println("mapper error: tokens[0]="+tokens[0]+", tokens[1]="+tokens[1]);
            }
        }
    }

    public static class Homework2Part1Reducer extends Reducer<Text, Text, Text, Text> {
        
        @Override
        public void reduce(Text key, Iterable<Text> values, Context context)
                throws IOException, InterruptedException {

            String actors = "";
            for (Text value : values) {
                actors += "\n\t" + value;
            }
            context.write(key, new Text(actors));
        }
    }    
	/**
	 * @param args
	 */
	public static void main(String[] args) throws Exception {
		System.out.println(Homework2Part1.class.getName());
		int exitCode = ToolRunner.run(new Homework2Part1(), args);
		System.exit(exitCode);
	}
}
