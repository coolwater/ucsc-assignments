rs.initiate( {
	_id: "rzsetConfig",
	configsvr: true,
	members: [
		{ _id : 0, host : "localhost:27018" }
	]
} );
print("initiated rzsetConfig configuration");
