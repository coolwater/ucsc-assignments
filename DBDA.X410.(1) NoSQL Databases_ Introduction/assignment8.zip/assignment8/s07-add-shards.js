// mongo localhost:27017
sh.addShard("rzset01/localhost:27019,localhost:27020");
sh.addShard("rzset02/localhost:27021,localhost:27022");

// list configured shards
db.getSiblingDB("config").shards.find();
db = db.getSiblingDB('admin');
db.runCommand({listshards: 1});

// enable sharding
sh.status();
db.adminCommand('listDatabases');
sh.enableSharding("test");
sh.status();
sh.shardCollection("test.users", {"username" : "hashed"});
sh.status();
print("added shards to test DB");

