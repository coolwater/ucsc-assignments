// mongo localhost:27019 s04-config-rzset01.js
config = {
	_id : "rzset01",
	members : [
		{_id : 0, host : "localhost:27019"},
		{_id : 1, host : "localhost:27020"}
	]
};
rs.initiate(config);
print("initiated rzset01 configuration");

