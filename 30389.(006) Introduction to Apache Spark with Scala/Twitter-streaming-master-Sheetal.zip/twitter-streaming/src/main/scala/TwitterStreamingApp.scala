import org.apache.spark.streaming.{ Seconds, StreamingContext }
import org.apache.spark.SparkContext
import org.apache.spark.SparkContext._
import org.apache.spark.SparkConf
import org.apache.spark.streaming.twitter._
import org.apache.spark.streaming.dstream.DStream

import java.util.Date
import org.apache.log4j.{Level, Logger}

/**
 * 	
  UCSC Extension Classes‎ > ‎Introduction to Spark with Scala‎ > ‎
  Assignment #4
  Twitter Tweets Sentiment Analysis
  
  The goal of this assignment is to leverage Spark Streaming component to consume Twitter data and 
  perform sentiment analysis on it. For each tweet, break the message into tokens, then remove 
  punctuation marks and stop words.
  
  * Simple sentiment analysis
  *     * Determine the score of whether a tweet has a positive, negative or neutral sentiment
  * A list of positive and negative words are provided
  * Display the sentiment score and tweet message to start out with (for debugging purposes)
  * Maintain # of positive, negative and neutral sentiment counts and print out them using window length of 10 and 30 seconds

 */
/**
 *
 * Use this as starting point for performing sentiment analysis on tweets from Twitter
 *
 *  To run this app
 *   ./sbt/sbt assembly
 *   $SPARK_HOME/bin/spark-submit --class "TwitterStreamingApp" --master local[*] ./target/scala-2.10/twitter-streaming-assembly-1.0.jar
 *      <consumer key> <consumer secret> <access token> <access token secret>
 */
object TwitterStreamingApp {
  def main(args: Array[String]) {

    if (args.length < 4) {
      System.err.println("Usage: TwitterStreamingApp <consumer key> <consumer secret> " +
        "<access token> <access token secret> [<filters>]")
      System.exit(1)
    }

    val Array(consumerKey, consumerSecret, accessToken, accessTokenSecret) = args.take(4)
    val filters = args.takeRight(args.length - 4)

    // Set the system properties so that Twitter4j library used by twitter stream
    // can use them to generate OAuth credentials
    System.setProperty("twitter4j.oauth.consumerKey", consumerKey)
    System.setProperty("twitter4j.oauth.consumerSecret", consumerSecret)
    System.setProperty("twitter4j.oauth.accessToken", accessToken)
    System.setProperty("twitter4j.oauth.accessTokenSecret", accessTokenSecret)

    // val sparkConf = new SparkConf().setAppName("TwitterPopularTags")
    // to run this application inside an IDE, comment out previous line and uncomment line below
    val sparkConf = new SparkConf().setAppName("TwitterPopularTags").setMaster("local[*]")

    // setup streaming context, with window of 5s capture
    val ssc = new StreamingContext(sparkConf, Seconds(5))
    // create twitter stream
    val stream = TwitterUtils.createStream(ssc, None, filters)

    // load stop words, positive words, and negative words
    val stopWordsRDD = ssc.sparkContext.textFile("src/main/resources/stop-words.txt")
    val posWordsRDD = ssc.sparkContext.textFile("src/main/resources/pos-words.txt")
    val negWordsRDD = ssc.sparkContext.textFile("src/main/resources/neg-words.txt")

    // convert the stop words, positive, and negative words RDDs to a Set
    val positiveWords = posWordsRDD.collect().toSet
    val negativeWords = negWordsRDD.collect().toSet
    val stopWords = stopWordsRDD.collect().toSet

    // filter only for English tweets
    val englishTweets = stream.filter(status => status.getUser().getLang() == "en")
    
    // WrappedArray of tweets
    // val tweetLines : DStream[Seq[String]] = englishTweets.map(status => (status.getText()).map(tweetLine => (tweetLine, tweetLine.toLowerCase().split(" ")))
    val tweetLines : DStream[(String, Seq[String])] = englishTweets.map(status => status.getText())
                                                                   .map(tweetLine => (tweetLine, tweetLine.toLowerCase()
                                                                   .split(" ")))
    // tweetLines.count().print()
    
    // tweetLines.print()
                                                                   
    // remove first word RT as re-tweet prefix, and eliminate any @[a-zA-Z-_:] tags, then count the tweet size
    def enWordsOnly(tweetTokens: Seq[String]): Seq[String] = tweetTokens.filter(word => word.matches("[a-z]+"))
    def firstWordRT(tweetTokens: Seq[String]): Seq[String] = tweetTokens.filterNot(word => word.equals("rt"))
    val tweetsRealWords : DStream[(String, Seq[String])] = tweetLines.map(r => (r._1, enWordsOnly(r._2)))
                                                                     .map(r => (r._1, firstWordRT(r._2)))
                                                                     .filter({ case (_, enWords) => enWords.length > 0 })
    // tweetsRealWords.print()

    // WORKING stop words elimination code
    // def removeStopWords(tweetTokens: Seq[String]): Seq[String] = tweetTokens.filterNot(word => stopWords.contains(word))
    // val tweetsNoStop : DStream[Seq[String]] = tweetsRealWords.map(r => removeStopWords(r))
    // tweetsNoStop.print()
    
    // Function Definitions
    // count positive and negative words in each tweet
    def posOrNegWord(word: String): Int = 
      (if (positiveWords.contains(word)) 1 else if (negativeWords.contains(word)) -1 else 0)
    
    // return 1 if tweet word belongs to the positive, negative, neurtal word sets
    def posWord(word: String): Int = 
      (if (positiveWords.contains(word)) 1 else 0)
    def negWord(word: String): Int = 
      (if (negativeWords.contains(word)) 1 else 0)
    def stopWord(word: String): Int = 
      (if (stopWords.contains(word)) 1 else 0)
    
    // functions to count the number of positive/negative/neutral words in the tweets word Seq
    def positiveScore(tweetTokens: Seq[String]): Int = tweetTokens.map(word => posWord(word)).sum
    def negativeScore(tweetTokens: Seq[String]): Int = tweetTokens.map(word => negWord(word)).sum
    def stopScore(tweetTokens: Seq[String]): Int = tweetTokens.map(word => stopWord(word)).sum
    // def firstTokenRT(tweetTokens: Seq[String]): Boolean = tweetTokens.head.equals("RT")
    
    // calculate individual tweet sentiment posWord > negWords for POSITIVE, 
    // posWord < netWord for NEGATIVE and NEUTRAL otherwise
    def sentimentScore(tweetTokens: Seq[String]): Int = tweetTokens.map(word => posOrNegWord(word)).sum
    def sentiment(tweetTokens: Seq[String]): String = { 
                                                        val score = sentimentScore(tweetTokens)                                                      
                                                        if (score > 0) s"POSITIVE" 
                                                        else if (score < 0) s"NEGATIVE" 
                                                        else s"NEUTRAL"
                                                      }
    // create a stream of tweet string, positive score, negative score, neutral score and the sentiment value    
    val tweetScores : DStream[(String, Int, Int, Int, String)] = 
      tweetsRealWords.map(to => (to._1, positiveScore(to._2), 
                                        negativeScore(to._2), 
                                        stopScore(to._2), 
                                        sentiment(to._2)))
    
    // for debugging purposes print the tweet scores and sentiment value for each RDD in the DStream
    tweetScores.foreachRDD(rdd => {
      println("\n**Tweet Sentiments**\n")
      rdd.foreach{ case (tweet, pos, neg, neutral, sentiment) => println("PosWD=%d NegWD=%d NeutWD=%d Sentiment=%s Tweet=%s".format(pos, neg, neutral, sentiment, tweet)) }
    })
    
    // group by twitter words that are POSTIVE, NEGATIVE and NEUTRAL in the last 10s & 30s time windows
    // this is evaluated every 5s as per the StreamingContext above
    val tweetSentimentCount10s = tweetScores.map(ts => (ts._5, 1)).reduceByKeyAndWindow((a:Int, b:Int) => a + b, Seconds(10))
    val tweetSentimentCount30s = tweetScores.map(ts => (ts._5, 1)).reduceByKeyAndWindow((a:Int, b:Int) => a + b, Seconds(30))

    // enable for debugging purpose to print the first RDD in the DStream
    // tweetSentimentCount10s.print()
    // tweetSentimentCount30s.print()
    
    // Print Tweet (POSITIVE/NEGATIVE/NEUTRAL) Sentiment counts for tweets in the last 10s window
    tweetSentimentCount10s.foreachRDD(rdd => {
      println("\nTweet sentiments in last 10 seconds")
      rdd.foreach { case (count, tag) => println("Count=%s (%s tweets)".format(tag, count)) }
    })
    // Print Tweet (POSITIVE/NEGATIVE/NEUTRAL) Sentiment counts for tweets in the last 30s window
    tweetSentimentCount30s.foreachRDD(rdd => {
      println("\nTweet sentiments in last 30 seconds")
      rdd.foreach { case (count, tag) => println("Count=%s (%s tweets)".format(tag, count)) }
    })
    
    // start tweets processing
    ssc.start()
    
    // await termination of tweets processing
    ssc.awaitTermination()
  }

}
