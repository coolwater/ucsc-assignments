package ucsc.hadoop.homework2;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.net.URI;
import java.util.HashMap;
import java.util.Map;

import jline.internal.Log;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;

public class HomeWork2BonusPart extends Configured implements Tool {
    
    /*
     * run method that sets up the Map Reduce environment
     * @see org.apache.hadoop.util.Tool#run(java.lang.String[])
     */
    public int run(String[] args) throws Exception {
        Configuration conf = getConf();
        
        if (args.length != 3) {
            System.err.println("Usage: HomeWork2BonusPart <input-file> <output-file> <lookup-cache-file>");
            System.exit(2);
        }
        
        Job job = Job.getInstance(conf);
        
        job.setJobName("HomeWork2BonusPart");
        job.setJarByClass(HomeWork2BonusPart.class);
        
        FileInputFormat.setInputPaths(job,  new Path(args[0]));
        FileOutputFormat.setOutputPath(job, new Path(args[1]));
        
        File cache = new File(args[2]);
        if (cache.isDirectory()) {
            for (File f : cache.listFiles())
                job.addCacheFile(new URI(f.getPath()));
        } else {
            job.addCacheFile(new URI(args[2]));
        }
        
        job.setMapperClass(Homework2BonusPartMapper.class);
        job.setReducerClass(Homework2BonusPartReducer.class);
        
        job.setInputFormatClass(TextInputFormat.class);
        job.setOutputFormatClass(TextOutputFormat.class);
        
        job.setMapOutputKeyClass(Text.class);
        job.setMapOutputValueClass(DoubleWritable.class);
        
        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(DoubleWritable.class);
        
        boolean result = job.waitForCompletion(true);
        return (result) ? 0 : 1;
        
    }

    public static class Homework2BonusPartMapper extends Mapper<LongWritable, Text, Text, DoubleWritable> {
        private LookupService lookupService;

        /*
         * [INFO] lookup table: imdb-weights.tsv
         * lookup key=Beginners2004 No weight found!
         * lookup key=Beginners2004 No weight found!
         * mapper: bad record (no YYYY): tokens[0]=Leacock, Viv, tokens[1]=Are We There Yet?
         */
        public class LookupService {
            
            private Map<String, Double> lookupTable = new HashMap<String, Double>();
            
            /*
             * initialize the lookup table, given the file URI, ignore movies with no YYYY.
             */
            public void initialize(URI uri) throws IOException {
                BufferedReader in = new BufferedReader(new FileReader(uri.getPath()));
                String line = null;
                
                try {
                    while ((line = in.readLine()) != null) {
                        // parse for <movie name> <year> <weight>
                        String[] tokens = line.toString().split("\\t");
                        if (tokens.length == 3) {
                            // lookup table entry: "<movie-name> (<year>)", weight
                            String movieyy = tokens[0]+tokens[1];
                            // System.out.println("put key movieyy="+movieyy+" weight="+Double.parseDouble(tokens[2]));
                            lookupTable.put(movieyy, Double.parseDouble(tokens[2]));
                        }
                    }
                } finally {
                    org.apache.commons.io.IOUtils.closeQuietly(in);
                }
            }
            
            /*
             * lookup function, given a movie name (name+year), return the weight, '0' returned if not movie found
             */
            public double lookup(String key) {
                double weight = 0.0;
                try {
                    weight = lookupTable.get(key);
                } catch (NullPointerException e) {
                    System.err.println("lookup key=" + key + " No weight found!");
                }
                return weight;
            }
        }
        
        /*
         * mapper setup: called before the map function, used to setup the lookup table movie->weight
         * @see org.apache.hadoop.mapreduce.Mapper#setup(org.apache.hadoop.mapreduce.Mapper.Context)
         */
        @Override
        public void setup(Context context) throws IOException {
            URI[] uriArray = context.getCacheFiles();
            
            if (uriArray.length != 1) {
                Log.info("expecting one lookup-file for distributed cache");
                
            } else {
                Log.info("lookup table: " + uriArray[0].getPath());
                lookupService = new LookupService();
                lookupService.initialize(uriArray[0]);
            }
        }
        
        /*
         * mapper: lookup weight of the movie the actor acted in, and create a tuple <actor>, <movie-weight>
         * @see org.apache.hadoop.mapreduce.Mapper#map(KEYIN, VALUEIN, org.apache.hadoop.mapreduce.Mapper.Context)
         */
        @Override
        public void map(LongWritable key, Text value, Context context) 
                throws IOException, InterruptedException {
            
            // values are separated by a tab
            String[] tokens = value.toString().split("\\t");            

            if (tokens.length == 3) {
                // actor name - token[0], movie name - tokens[1], year of production - token[2]
                String movieyy = tokens[1]+tokens[2];
                double weight = lookupService.lookup(movieyy);
                // ignore actor's movie with no weight assignment - bad data
                if (weight != 0.0) {
                    context.write(new Text(tokens[0]), new DoubleWritable(weight));
                }
            } else {
                System.err.println("mapper: bad record (no YYYY): tokens[0]="+tokens[0]+", tokens[1]="+tokens[1]);
            }
        }
    }

    /*
     * Reducer - calculates the average weight of the movies the actor acted in.
     */
    public static class Homework2BonusPartReducer extends Reducer<Text, DoubleWritable, Text, DoubleWritable> {
        
        @Override
        public void reduce(Text key, Iterable<DoubleWritable> values, Context context)
                throws IOException, InterruptedException {

            double netweight = 0.0;
            int nmovies = 0;
            for (DoubleWritable value : values) {
                netweight += value.get();
                nmovies++;
            }
            if (nmovies > 0)
                context.write(key, new DoubleWritable(netweight/nmovies));
        }
    }    

    /**
     * @param args
     */
    public static void main(String[] args) throws Exception {
        System.out.println(HomeWork2BonusPart.class.getName());
        int exitCode = ToolRunner.run(new HomeWork2BonusPart(), args);
        System.exit(exitCode);
    }

}