#!/bin/bash -x
gnome-terminal -e "mongo localhost:27017 s07-add-shards.js"

