// mongo localhost:27017
use test
db.users.getShardDistribution()
db.users.find({username: "user62123"})
db.users.find({username: "user62123"}).explain()
db.users.find({username: "user80000"}).explain()
