#!/bin/bash -x
gnome-terminal -e "mongod --configsvr --replSet rzsetConfig --dbpath /data/configsrv --port 27018"
sleep 5
gnome-terminal -e "mongos --configdb rzsetConfig/localhost:27018 --port 27017"
sleep 5
gnome-terminal -e "mongo localhost:27019 s04-config-rzset01.js"
sleep 5
gnome-terminal -e "mongo localhost:27021 s05-config-rzset02.js"
sleep 5
gnome-terminal -e "mongo --host localhost --port 27018 s06-config-rzsetConfig.js"
sleep 5



