package ucsc.hadoop.homework2;

import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;

public class Homework2Part2 extends Configured implements Tool {
    
    public int run(String[] args) throws Exception {
        Configuration conf = getConf();
        
        if (args.length != 2) {
            System.err.println("Usage: Homework2Part2 <input-file> <output-file>");
            System.exit(2);
        }
        
        Job job = Job.getInstance(conf);
        
        job.setJobName("Homework2Part2");
        job.setJarByClass(Homework2Part2.class);
        
        FileInputFormat.setInputPaths(job,  new Path(args[0]));
        FileOutputFormat.setOutputPath(job, new Path(args[1]));
        
        job.setMapperClass(Homework2Part2Mapper.class);
        job.setReducerClass(Homework2Part2Reducer.class);
        
        job.setInputFormatClass(TextInputFormat.class);
        job.setOutputFormatClass(TextOutputFormat.class);
        
        job.setMapOutputKeyClass(Text.class);
        job.setMapOutputValueClass(Text.class);
        
        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(IntWritable.class);
        
        boolean result = job.waitForCompletion(true);
        return (result) ? 0 : 1;
        
    }

    public static class Homework2Part2Mapper extends Mapper<LongWritable, Text, Text, Text> {
        
        @Override
        public void map(LongWritable key, Text value, Context context) 
                throws IOException, InterruptedException {
            
            // values are separated by a tab
            String[] tokens = value.toString().split("\\t");
            
            if (tokens.length == 3) {
                // actor name - token[0], movie name - tokens[1], year of production - token[2]
                context.write(new Text(tokens[0]), new Text(tokens[0]+" ("+tokens[2]+")"));
            } else {
                System.err.println("mapper error: tokens[0]="+tokens[0]+", tokens[1]="+tokens[1]);
            }
        }
    }

    public static class Homework2Part2Reducer extends Reducer<Text, Text, Text, IntWritable> {
        
        @Override
        public void reduce(Text key, Iterable<Text> values, Context context)
                throws IOException, InterruptedException {

            int nmovies = 0;
            for (Text value : values) {
                nmovies += 1;
            }
            context.write(key, new IntWritable(nmovies));
        }
    }    

	/**
	 * @param args
	 */
	public static void main(String[] args) throws Exception {
		System.out.println(Homework2Part2.class.getName());
		int exitCode = ToolRunner.run(new Homework2Part2(), args);
		System.exit(exitCode);
	}

}
