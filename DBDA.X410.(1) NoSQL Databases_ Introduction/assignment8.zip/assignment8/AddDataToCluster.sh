#!/bin/bash -x
gnome-terminal -e "mongo localhost:27019 s08a-check-shard01-status.js"
sleep 1
gnome-terminal -e "mongo localhost:27021 s08b-check-shard02-status.js"
sleep 1
gnome-terminal -e "mongo localhost:27017 s07-add-data2cluster.js"
sleep 1

