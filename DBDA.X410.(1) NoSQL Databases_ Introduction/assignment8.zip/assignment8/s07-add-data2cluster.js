// add documents into the collection
db = db.getSiblingDB('test')
for (var i=0; i<100000; i++) {
	db.users.insert({"username" : "user"+i, "created_at" : new Date()});
	if (i % 1000 == 0)
		print("inserted 100 user records into mongodb");
}
print("Inserted "+ db.users.find().count() + " user records");
