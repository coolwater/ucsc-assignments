mongoimport --db usdata --collection cityinfo --type json --file zips.json
mongo
use usdata

db.cityinfo.aggregate([
{ $group:{_id: { state: "$state", city: "$city" },pop: { $sum: "$pop" }}},
{ $sort: { pop: 1 } },
{ $group:{_id : "$_id.state",smallestCity: { $first: "$_id.city"}}},
{ $project:{ _id: 0,state: "$_id",city: "$smallestCity" }}
])

db.cityinfo.aggregate([
{ $group:{_id: { state: "$state", city: "$city" },pop: { $sum: "$pop" }}},
{ $sort: { pop: 1 } },
{ $group:{_id : "$_id.state",smallestCity: { $first: "$_id.city"}, pop: {$first: "$pop"}}}
])

db.cityinfo.aggregate([
{ $group:{_id: { state: "$state", city: "$city" },pop: { $sum: "$pop" }}},
{ $sort: { pop: 1 } },
{ $match: {"_id.state": "NH" }},
{ $group:{_id : "$_id.state",smallestCity: { $first: "$_id.city"}, pop: {$first: "$pop"}}}
])

function smallestCity(st) {
var dbc = db.cityinfo.aggregate([
{ $group:{_id: { state: "$state", city: "$city" },pop: { $sum: "$pop" }}},
{ $sort: { pop: 1 } },
{ $match: {"_id.state": st }},
{ $group:{_id : "$_id.state",smallestCity: { $first: "$_id.city"}, pop: {$first: "$pop"}}}
]);
return dbc;
}
smallestCity("NH")
smallestCity("NY")

db.cityinfo.aggregate([
{ $group:{_id: { state: "$state", city: "$city" },pop: { $sum: "$pop" }}},
{ $sort: { pop: 1 } },
{ $group:{_id : "$_id.state",largestCity: { $last: "$_id.city"}}},
{ $project:{ _id: 0,state: "$_id",city: "$largestCity" }}
])

db.cityinfo.aggregate([
{ $group:{_id: { state: "$state", city: "$city" },pop: { $sum: "$pop" }}},
{ $sort: { pop: -1 } },
{ $group:{_id : "$_id.state",largestCity: { $first: "$_id.city"}, pop: {$first: "$pop"}}},
{ $sort: {pop: -1}}
])

function largestCity(st) {
var dbc = db.cityinfo.aggregate([
{ $group:{_id: { state: "$state", city: "$city" },pop: { $sum: "$pop" }}},
{ $sort: { pop: -1 } },
{ $match: {"_id.state": st }},
{ $group:{_id : "$_id.state",largestCity: { $first: "$_id.city"}, pop: {$first: "$pop"}}}
]);
return dbc;
}

largestCity("NH")
largestCity("NY")

# solution 1
db.cityinfo.aggregate( [
  { $group: { _id: { state: "$state", city: "$city" }, pop: { $sum: "$pop" } } },
  { $sort: {pop: -1}},
  { $group: {_id: { state : "$_id.state"}, cities: { $push:{ city: "$_id.city"}}}
}]).map( function(data) {
  data.cities = data.cities.slice(2, 3);
  return {state: data._id.state, city: (data.cities.length > 0) ? data.cities[0].city : "no city found"
}});

# solution 2
db.cityinfo.aggregate( [
  {$group:{_id:{state:"$state",city:"$city"}, pop: {$sum: "$pop" } } } ,
  {$sort: { "_id.state" :1 , pop: -1 } } ,
  {$group:{ _id: "$_id.state", rankcity: {$push: { pop: "$pop" , city: "$_id.city" } } } } ,
  {$project: { ThirdLargestCity: { $slice: ["$rankcity", 2 , 1] } } },
  {$sort: { _id: 1}}
])


# solution 3
db.cityinfo.aggregate( [
{ $group: { _id: { state: "$state", city: "$city" },pop: { $sum: "$pop" } } },
{ $project: { _id : 1, pop : 1, state : {
$let: {
vars : { statez : "$_id.state" },
in: { $toUpper: "$$statez" }
} } }},
{ $sort: { _id : 1 } },
{ $out: "tmpcityinfo"} ])

db.cityinfo.aggregate( [
{ $project: { _id : 0, state : 1 }} ,
{ $group: { _id : "$state" }},
{ $out: "tmpstates" }
])

function processState( st, n ) {
if (n <= 0) return;
var citycnt = db.tmpcityinfo.find( { state : st }).count();
if (n > citycnt) return; var index = n - 1;
var nthlargestcity = db.tmpcityinfo.find( { state : st }).sort( { pop : -1 } )[index];
print(st + ' ' + n + ' largest=' + nthlargestcity._id.city);
}
//Test processState
processState("CA", 5)
processState("NY", 5)

//loop through each state
var curstate = db.tmpstates.find();
var statecnt=curstate.count();
for (var i = 1; i < statecnt; i++) {
processState(curstate[i]._id, 3);
}
//cleanup
db.tmpcityinfo.drop()
db.tmpstates.drop()

